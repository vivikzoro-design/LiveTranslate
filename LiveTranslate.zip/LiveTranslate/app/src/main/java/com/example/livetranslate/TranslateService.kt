package com.example.livetranslate

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.IntentCompat
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

/**
 * خدمة أمامية:
 * 1) تلتقط صوت تشغيل الهاتف (تيك توك/يوتيوب/أي مشغل) عبر AudioPlaybackCapture
 * 2) ترسل كل مقطع (~6 ثوانٍ) إلى Whisper على Groq (يكتشف اللغة تلقائياً)
 * 3) تترجم النص إلى العربية على الجهاز (ML Kit)
 * 4) تعرض الترجمة في نافذة عائمة فوق كل التطبيقات
 */
class TranslateService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "com.example.livetranslate.STOP"
        private const val CHANNEL = "live_translate"
        private const val SAMPLE_RATE = 16000
        private const val CHUNK_SECONDS = 6
        private const val SILENCE_RMS = 150.0
    }

    private val ui = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    @Volatile private var active = false
    private var worker: Thread? = null

    private var wm: WindowManager? = null
    private var overlay: View? = null
    private var subtitle: TextView? = null

    // طابور صغير: إن تأخرت الشبكة نتخطى المقاطع القديمة بدل التراكم
    private val executor = ThreadPoolExecutor(
        1, 1, 0L, TimeUnit.MILLISECONDS,
        ArrayBlockingQueue(2), ThreadPoolExecutor.DiscardOldestPolicy()
    )
    private val translators = HashMap<String, Translator>()

    // ------------------------------------------------------------ دورة الحياة

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (active) return START_NOT_STICKY

        startForegroundCompat()

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                ui.post { stopSelf() }
            }
        }, ui)

        createOverlay()
        startCapture()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        active = false
        overlay?.let { runCatching { wm?.removeView(it) } }
        overlay = null
        executor.shutdownNow()
        translators.values.forEach { runCatching { it.close() } }
        translators.clear()
        projection?.stop()
        projection = null
        super.onDestroy()
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, TranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle(getString(R.string.notif_title))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, getString(R.string.notif_stop), stopPi).build())
            .build()
        startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    // --------------------------------------------------------- النافذة العائمة

    @SuppressLint("ClickableViewAccessibility")
    private fun createOverlay() {
        val wmgr = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = wmgr
        val dp = resources.displayMetrics.density

        val text = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 18f
            maxLines = 5
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_ANY_RTL
            text = getString(R.string.overlay_listening)
        }
        subtitle = text

        val close = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 20f
            setPadding((12 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt())
            this.text = "✕"
            setOnClickListener { stopSelf() }
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(0xCC000000.toInt())
                cornerRadius = 16 * dp
            }
            setPadding((14 * dp).toInt(), (10 * dp).toInt(), (10 * dp).toInt(), (10 * dp).toInt())
            addView(text, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(close)
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            y = (140 * dp).toInt()
            x = 0
        }

        // سحب النافذة بالإصبع لتحريكها للأعلى/الأسفل
        var startY = 0
        var downY = 0f
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startY = lp.y
                    downY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.y = (startY - (e.rawY - downY)).toInt().coerceAtLeast(0)
                    wmgr.updateViewLayout(box, lp)
                    true
                }
                else -> false
            }
        }

        wmgr.addView(box, lp)
        overlay = box
    }

    private fun show(message: String) {
        ui.post { subtitle?.text = message }
    }

    // ----------------------------------------------------------------- الالتقاط

    @SuppressLint("MissingPermission")
    private fun startCapture() {
        val proj = projection ?: return
        val config = AudioPlaybackCaptureConfiguration.Builder(proj)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val record = try {
            AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(minBuf * 4)
                .setAudioPlaybackCaptureConfig(config)
                .build()
        } catch (e: Exception) {
            show("⚠️ تعذّر التقاط الصوت: ${e.message}")
            return
        }

        active = true
        worker = Thread { captureLoop(record) }.also { it.start() }
    }

    private fun captureLoop(rec: AudioRecord) {
        val chunkSamples = SAMPLE_RATE * CHUNK_SECONDS
        val buf = ShortArray(4096)
        var chunk = ShortArray(chunkSamples)
        var n = 0
        try {
            rec.startRecording()
            while (active) {
                val r = rec.read(buf, 0, buf.size)
                if (r < 0) break
                if (r == 0) continue
                var i = 0
                while (i < r) {
                    val c = minOf(r - i, chunkSamples - n)
                    System.arraycopy(buf, i, chunk, n, c)
                    n += c
                    i += c
                    if (n == chunkSamples) {
                        submit(chunk)
                        chunk = ShortArray(chunkSamples)
                        n = 0
                    }
                }
            }
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
    }

    private fun submit(chunk: ShortArray) {
        var sum = 0.0
        for (s in chunk) sum += s.toDouble() * s
        val rms = sqrt(sum / chunk.size)
        if (rms < SILENCE_RMS) return // صمت: لا نرسل شيئاً
        runCatching { executor.execute { process(chunk) } }
    }

    // ------------------------------------------------------- التعرف + الترجمة

    private fun process(chunk: ShortArray) {
        val result = try {
            transcribe(toWav(chunk))
        } catch (e: Exception) {
            show("⚠️ لا يوجد اتصال بالإنترنت")
            return
        } ?: return

        val text = result.first.trim()
        if (text.length < 2) return

        val src = langCode(result.second)
        val shown = when {
            src == null || src == TranslateLanguage.ARABIC -> text
            else -> translate(text, src) ?: text
        }
        show(shown)
    }

    /** يرسل WAV إلى Groq Whisper ويعيد (النص، اسم اللغة). */
    private fun transcribe(wav: ByteArray): Pair<String, String>? {
        val key = getSharedPreferences("cfg", MODE_PRIVATE).getString("key", "")?.trim().orEmpty()
        val boundary = "----LT" + System.currentTimeMillis()
        val conn = (URL("https://api.groq.com/openai/v1/audio/transcriptions")
            .openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 10000
            readTimeout = 30000
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }

        DataOutputStream(conn.outputStream).use { out ->
            fun field(name: String, value: String) {
                out.writeBytes(
                    "--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n"
                )
            }
            field("model", "whisper-large-v3-turbo")
            field("response_format", "verbose_json")
            field("temperature", "0")
            out.writeBytes(
                "--$boundary\r\nContent-Disposition: form-data; name=\"file\"; " +
                    "filename=\"audio.wav\"\r\nContent-Type: audio/wav\r\n\r\n"
            )
            out.write(wav)
            out.writeBytes("\r\n--$boundary--\r\n")
        }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()

        if (code !in 200..299) {
            show(
                when (code) {
                    401 -> "⚠️ مفتاح API غير صحيح"
                    429 -> "⚠️ تجاوزت الحد المجاني مؤقتاً، انتظر قليلاً"
                    else -> "⚠️ خطأ من الخادم ($code)"
                }
            )
            return null
        }
        val json = JSONObject(body)
        return json.optString("text") to json.optString("language")
    }

    /** اسم اللغة من Whisper ("english") -> رمز ML Kit ("en") أو null إن لم تُدعم. */
    private val nameToCode: Map<String, String> by lazy {
        val map = HashMap<String, String>()
        for (l in Locale.getAvailableLocales()) {
            if (l.language.isNotEmpty() && l.country.isEmpty() && l.variant.isEmpty()) {
                map[l.getDisplayLanguage(Locale.ENGLISH).lowercase()] = l.language
            }
        }
        map
    }

    private fun langCode(whisperName: String): String? {
        val iso = nameToCode[whisperName.trim().lowercase()] ?: return null
        return TranslateLanguage.fromLanguageTag(iso)
    }

    private fun translate(text: String, src: String): String? {
        return try {
            var tr = translators[src]
            if (tr == null) {
                show("⏳ جارٍ تحميل نموذج الترجمة لهذه اللغة (مرة واحدة)…")
                tr = Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(src)
                        .setTargetLanguage(TranslateLanguage.ARABIC)
                        .build()
                )
                translators[src] = tr
            }
            Tasks.await(tr.downloadModelIfNeeded(DownloadConditions.Builder().build()))
            Tasks.await(tr.translate(text))
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------------- WAV

    private fun toWav(pcm: ShortArray): ByteArray {
        val dataLen = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt(36 + dataLen)
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1)                    // PCM
        bb.putShort(1)                    // mono
        bb.putInt(SAMPLE_RATE)
        bb.putInt(SAMPLE_RATE * 2)        // byte rate
        bb.putShort(2)                    // block align
        bb.putShort(16)                   // bits per sample
        bb.put("data".toByteArray())
        bb.putInt(dataLen)
        for (s in pcm) bb.putShort(s)
        return bb.array()
    }
}
