package com.example.livetranslate

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/**
 * ترجمة مصاحبة: الكلام -> نص (SpeechRecognizer) -> ترجمة فورية (ML Kit).
 * تظهر الترجمة أثناء الكلام (نتائج جزئية) وتُثبَّت عند انتهاء الجملة.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var spinnerFrom: Spinner
    private lateinit var spinnerTo: Spinner
    private lateinit var tvStatus: TextView
    private lateinit var tvOriginal: TextView
    private lateinit var tvTranslated: TextView
    private lateinit var scrollOriginal: ScrollView
    private lateinit var scrollTranslated: ScrollView
    private lateinit var btnToggle: Button

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var translator: Translator? = null
    private var modelReady = false
    private var listening = false

    // النصوص المثبّتة (جمل مكتملة)
    private val finalOriginal = StringBuilder()
    private val finalTranslated = StringBuilder()

    // لتجاهل نتائج ترجمة قديمة وصلت متأخرة
    private var requestId = 0

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening() else tvStatus.setText(R.string.status_no_permission)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinnerFrom = findViewById(R.id.spinnerFrom)
        spinnerTo = findViewById(R.id.spinnerTo)
        tvStatus = findViewById(R.id.tvStatus)
        tvOriginal = findViewById(R.id.tvOriginal)
        tvTranslated = findViewById(R.id.tvTranslated)
        scrollOriginal = findViewById(R.id.scrollOriginal)
        scrollTranslated = findViewById(R.id.scrollTranslated)
        btnToggle = findViewById(R.id.btnToggle)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, LANGUAGES)
        spinnerFrom.adapter = adapter
        spinnerTo.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, LANGUAGES)
        spinnerFrom.setSelection(0) // العربية
        spinnerTo.setSelection(1)   // الإنجليزية

        val onChange = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prepareTranslator()
                if (listening) restartListening()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spinnerFrom.onItemSelectedListener = onChange
        spinnerTo.onItemSelectedListener = onChange

        findViewById<Button>(R.id.btnSwap).setOnClickListener {
            val f = spinnerFrom.selectedItemPosition
            val t = spinnerTo.selectedItemPosition
            spinnerFrom.setSelection(t)
            spinnerTo.setSelection(f)
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clearAll() }
        btnToggle.setOnClickListener { if (listening) stopListening() else requestAndStart() }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            tvStatus.setText(R.string.status_no_recognizer)
            btnToggle.isEnabled = false
        }
    }

    // ---------------------------------------------------------------- الترجمة

    private fun fromLang() = spinnerFrom.selectedItem as Lang
    private fun toLang() = spinnerTo.selectedItem as Lang

    /** ينشئ المترجم للغتين المختارتين ويحمّل النموذج إن لزم. */
    private fun prepareTranslator() {
        translator?.close()
        modelReady = false

        val from = fromLang()
        val to = toLang()
        if (from.mlKit == to.mlKit) {
            // نفس اللغة: لا حاجة للترجمة
            translator = null
            modelReady = true
            return
        }

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(from.mlKit)
            .setTargetLanguage(to.mlKit)
            .build()
        val t = Translation.getClient(options)
        translator = t

        tvStatus.setText(R.string.status_downloading)
        t.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                if (translator === t) {
                    modelReady = true
                    tvStatus.setText(if (listening) R.string.status_listening else R.string.status_idle)
                }
            }
            .addOnFailureListener {
                if (translator === t) tvStatus.setText(R.string.status_download_failed)
            }
    }

    private fun translate(text: String, onDone: (String) -> Unit) {
        val t = translator
        if (t == null) { onDone(text); return } // نفس اللغة
        if (!modelReady || text.isBlank()) return
        t.translate(text)
            .addOnSuccessListener { onDone(it) }
    }

    // ----------------------------------------------------------- التعرف على الكلام

    private fun requestAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) startListening() else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startListening() {
        listening = true
        btnToggle.setText(R.string.stop)
        tvStatus.setText(if (modelReady) R.string.status_listening else R.string.status_downloading)
        if (translator == null && !modelReady) prepareTranslator()

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        recognizer?.startListening(recognizerIntent())
    }

    private fun stopListening() {
        listening = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        btnToggle.setText(R.string.start)
        tvStatus.setText(R.string.status_idle)
    }

    private fun restartListening() {
        stopListening()
        handler.postDelayed({ startListening() }, 300)
    }

    private fun recognizerIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, fromLang().locale)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
    }

    /** إعادة تشغيل الاستماع بعد انتهاء كل جملة ليبقى التطبيق يستمع باستمرار. */
    private fun relisten(delayMs: Long = 200) {
        if (!listening) return
        handler.postDelayed({
            if (listening) recognizer?.startListening(recognizerIntent())
        }, delayMs)
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty()
            if (text.isBlank()) return
            showPartial(text)
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty()
            if (text.isNotBlank()) commitFinal(text)
            relisten()
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    stopListening()
                    tvStatus.setText(R.string.status_no_permission)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    recognizer?.cancel()
                    relisten(800)
                }
                else -> relisten() // صمت أو لا تطابق: نستمر في الاستماع
            }
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    // ------------------------------------------------------------------ العرض

    private fun showPartial(text: String) {
        val id = ++requestId
        tvOriginal.text = finalOriginal.toString() + text
        scrollDown(scrollOriginal)
        translate(text) { translated ->
            if (id == requestId) {
                tvTranslated.text = finalTranslated.toString() + translated
                scrollDown(scrollTranslated)
            }
        }
    }

    private fun commitFinal(text: String) {
        val id = ++requestId
        finalOriginal.append(text).append('\n')
        tvOriginal.text = finalOriginal.toString()
        scrollDown(scrollOriginal)
        translate(text) { translated ->
            // نثبّت الترجمة النهائية حتى لو وصلت متأخرة
            finalTranslated.append(translated).append('\n')
            tvTranslated.text = finalTranslated.toString()
            scrollDown(scrollTranslated)
        }
    }

    private fun clearAll() {
        requestId++
        finalOriginal.clear()
        finalTranslated.clear()
        tvOriginal.text = ""
        tvTranslated.text = ""
    }

    private fun scrollDown(sv: ScrollView) = sv.post { sv.fullScroll(View.FOCUS_DOWN) }

    override fun onStop() {
        super.onStop()
        if (listening) stopListening()
    }

    override fun onDestroy() {
        super.onDestroy()
        recognizer?.destroy()
        translator?.close()
    }
}
