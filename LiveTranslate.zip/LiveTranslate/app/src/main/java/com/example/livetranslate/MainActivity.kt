package com.example.livetranslate

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** شاشة الإعداد: مفتاح API + الأذونات + بدء/إيقاف الخدمة الخلفية. */
class MainActivity : AppCompatActivity() {

    private lateinit var etKey: EditText
    private lateinit var tvStatus: TextView

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasMic()) askProjection() else tvStatus.setText(R.string.status_no_mic)
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, TranslateService::class.java)
                    .putExtra(TranslateService.EXTRA_CODE, res.resultCode)
                    .putExtra(TranslateService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
                tvStatus.setText(R.string.status_running)
            } else {
                tvStatus.setText(R.string.status_denied)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etKey = findViewById(R.id.etKey)
        tvStatus = findViewById(R.id.tvStatus)

        etKey.setText(getSharedPreferences("cfg", MODE_PRIVATE).getString("key", ""))

        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        findViewById<Button>(R.id.btnStart).setOnClickListener { startFlow() }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, TranslateService::class.java))
            tvStatus.setText(R.string.status_stopped)
        }
    }

    private fun startFlow() {
        val key = etKey.text.toString().trim()
        if (key.isEmpty()) {
            tvStatus.setText(R.string.status_need_key)
            return
        }
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("key", key).apply()

        if (!Settings.canDrawOverlays(this)) {
            tvStatus.setText(R.string.status_need_overlay)
            return
        }

        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(perms.toTypedArray())
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun askProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
