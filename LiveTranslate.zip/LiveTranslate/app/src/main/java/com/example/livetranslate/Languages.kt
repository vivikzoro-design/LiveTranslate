package com.example.livetranslate

/**
 * لغة مدعومة.
 * mlKit  : رمز اللغة في ML Kit Translate
 * locale : وسم اللغة المستخدم في التعرف على الكلام
 */
data class Lang(val name: String, val mlKit: String, val locale: String) {
    override fun toString() = name
}

val LANGUAGES = listOf(
    Lang("العربية", "ar", "ar-SA"),
    Lang("English", "en", "en-US"),
    Lang("Français", "fr", "fr-FR"),
    Lang("Español", "es", "es-ES"),
    Lang("Deutsch", "de", "de-DE"),
    Lang("Türkçe", "tr", "tr-TR"),
    Lang("Русский", "ru", "ru-RU"),
    Lang("فارسی", "fa", "fa-IR"),
    Lang("اردو", "ur", "ur-PK"),
    Lang("हिन्दी", "hi", "hi-IN"),
    Lang("Italiano", "it", "it-IT"),
    Lang("Português", "pt", "pt-BR"),
    Lang("中文", "zh", "zh-CN"),
    Lang("日本語", "ja", "ja-JP"),
    Lang("한국어", "ko", "ko-KR"),
    Lang("Bahasa Indonesia", "id", "id-ID"),
)
